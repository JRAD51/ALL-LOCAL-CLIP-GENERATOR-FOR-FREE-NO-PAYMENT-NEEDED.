$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'AutoClip-Environment.ps1')
$paths = Initialize-AutoClipEnvironment
$env:AUTOCLIP_ROOT = $paths.WorkRoot
& (Join-Path $paths.Desktop 'electron\electron.exe') $paths.Desktop
