$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'AutoClip-Environment.ps1')
$paths = Initialize-AutoClipEnvironment
Set-Location $paths.AppRoot
& $paths.Python -m autoclip.cli serve --host 127.0.0.1
if ($LASTEXITCODE -ne 0) { Read-Host 'AutoClip stopped. Press Enter to close this window' }
