function Initialize-AutoClipEnvironment {
    $installRoot = Join-Path $env:LOCALAPPDATA 'AutoClip'
    $workRoot = Join-Path $installRoot 'work'
    if (!(Test-Path -LiteralPath (Join-Path $workRoot 'tools\python312\python.exe'))) {
        throw 'AutoClip is not set up yet. Double-click Setup AutoClip.cmd first.'
    }
    $ollamaRoot = Join-Path $workRoot 'tools\ollama'
    $ffmpegRoot = Join-Path $workRoot 'tools\ffmpeg-full\bin'
    $ollamaHome = Join-Path $workRoot 'ollama-home'
    $ollamaModels = Join-Path $workRoot 'ollama-models'
    $hfRoot = Join-Path $workRoot 'hf-home'
    $tempRoot = Join-Path $workRoot 'temp'
    New-Item -ItemType Directory -Force -Path $ollamaHome,$ollamaModels,$hfRoot,$tempRoot | Out-Null
    $env:AUTOCLIP_HOME = Join-Path $workRoot 'autoclip-data'
    $env:OLLAMA_MODELS = $ollamaModels
    $env:OLLAMA_HOST = '127.0.0.1:11435'
    $env:OLLAMA_NO_CLOUD = '1'
    $env:HF_HOME = $hfRoot
    $env:HF_HUB_CACHE = Join-Path $hfRoot 'hub'
    $env:HUGGINGFACE_HUB_CACHE = $env:HF_HUB_CACHE
    $env:TEMP = $tempRoot
    $env:TMP = $tempRoot
    $env:PATH = "$ollamaRoot;$ffmpegRoot;$(Join-Path $workRoot 'tools\python312');$(Join-Path $workRoot 'tools\python312\Scripts');$env:PATH"
    $api = 'http://127.0.0.1:11435/api/tags'
    try { $null = Invoke-RestMethod -Uri $api -TimeoutSec 2 }
    catch {
        $realProfile = $env:USERPROFILE
        $env:HOME = $ollamaHome
        $env:USERPROFILE = $ollamaHome
        Start-Process -FilePath (Join-Path $ollamaRoot 'ollama.exe') -ArgumentList 'serve' -WorkingDirectory $workRoot -WindowStyle Hidden
        $env:USERPROFILE = $realProfile
        $ready = $false
        for ($i=0; $i -lt 30; $i++) { Start-Sleep -Seconds 1; try { $null = Invoke-RestMethod -Uri $api -TimeoutSec 2; $ready=$true; break } catch {} }
        if (!$ready) { throw 'AutoClip local AI did not start. Restart Windows and try again.' }
    }
    return [pscustomobject]@{ InstallRoot=$installRoot; WorkRoot=$workRoot; AppRoot=(Join-Path $workRoot 'autoclip-main'); Python=(Join-Path $workRoot 'tools\python312\python.exe'); Desktop=(Join-Path $installRoot 'desktop') }
}
