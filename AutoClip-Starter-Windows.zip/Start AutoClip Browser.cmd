@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\AutoClip\Start-AutoClip-Browser.ps1"
if errorlevel 1 pause
