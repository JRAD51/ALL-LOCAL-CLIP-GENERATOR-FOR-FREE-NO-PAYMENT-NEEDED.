AutoClip Windows Starter

This is the small starter download for the local AutoClip app. It does not include model or tool binaries, so the ZIP is small. First-time setup needs internet and several gigabytes of free disk space. After setup, the AI models and video tools stay on this PC and processing runs locally.

SETUP
1. Extract the ZIP.
2. Double-click Setup AutoClip.cmd and leave the setup window open until it says AutoClip is ready. Setup downloads Python packages, FFmpeg, Ollama, the local Llama model, Whisper's small model, and the Electron window runtime. It may take a while.
3. Use the AutoClip Browser or AutoClip Desktop shortcut added to your desktop.

The browser shortcut opens the local app in your browser. The desktop shortcut opens the same app in an Electron window. Keep the installed AutoClip folder under %LOCALAPPDATA%\AutoClip intact.

The local AI service uses a loopback-only port and Ollama cloud features are disabled. Upload a local video for an offline session. A YouTube URL still needs internet to fetch its source video.

If setup is interrupted, run Setup AutoClip.cmd again. It reuses components already installed and tries the missing steps again.
