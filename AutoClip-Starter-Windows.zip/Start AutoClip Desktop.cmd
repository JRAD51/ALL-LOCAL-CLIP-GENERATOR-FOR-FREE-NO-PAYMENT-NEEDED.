@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\AutoClip\Start-AutoClip-Desktop.ps1"
if errorlevel 1 pause
