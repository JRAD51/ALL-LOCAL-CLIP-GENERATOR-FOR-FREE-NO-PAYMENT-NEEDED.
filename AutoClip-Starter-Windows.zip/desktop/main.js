const { app, BrowserWindow, dialog, shell } = require('electron')
const { spawn, execFile } = require('node:child_process')
const fs = require('node:fs')
const path = require('node:path')
const http = require('node:http')

let backend = null
let windowRef = null
let shuttingDown = false

function findRoot() {
  if (process.env.AUTOCLIP_ROOT) return path.resolve(process.env.AUTOCLIP_ROOT)
  const starts = app.isPackaged
    ? [path.resolve(path.dirname(process.execPath), '..', 'work'), path.resolve(path.dirname(process.execPath), 'work')]
    : [path.resolve(__dirname, '..')]
  for (const start of starts) {
    if (fs.existsSync(path.join(start, 'autoclip-main', 'backend', 'autoclip')) &&
        fs.existsSync(path.join(start, 'tools', 'python312', 'python.exe'))) return start
  }
  throw new Error('AutoClip files were not found. Extract the complete download and keep the desktop and work folders together.')
}

function probe(url, timeout = 1200) {
  return new Promise(resolve => {
    const req = http.get(url, res => { res.resume(); resolve(res.statusCode >= 200 && res.statusCode < 500) })
    req.setTimeout(timeout, () => { req.destroy(); resolve(false) })
    req.on('error', () => resolve(false))
  })
}

function waitFor(url, tries = 75) {
  return new Promise(async (resolve, reject) => {
    for (let i = 0; i < tries; i++) {
      if (shuttingDown) return reject(new Error('AutoClip startup was cancelled.'))
      if (await probe(url)) return resolve()
      if (backend && backend.exitCode !== null) return reject(new Error('The local AutoClip service stopped during startup. Check work\\autoclip-data\\desktop.log.'))
      await new Promise(r => setTimeout(r, 1000))
    }
    reject(new Error('AutoClip did not start in time. Check work\\autoclip-data\\desktop.log.'))
  })
}

function runOllamaCheck(exe, env) {
  return new Promise(resolve => execFile(exe, ['ps'], { env, windowsHide: true, timeout: 4000 }, err => resolve(!err)))
}

async function launch() {
  const root = findRoot()
  const appRoot = path.join(root, 'autoclip-main')
  const tools = path.join(root, 'tools')
  const ollamaRoot = path.join(tools, 'ollama')
  const data = path.join(root, 'autoclip-data')
  const temp = path.join(root, 'temp')
  for (const dir of [data, temp, path.join(root, 'hf-home', 'hub')]) fs.mkdirSync(dir, { recursive: true })
  const configPath = path.join(data, 'config.json')
  const bundledConfig = path.join(root, 'config.json')
  if (!fs.existsSync(configPath) && fs.existsSync(bundledConfig)) fs.copyFileSync(bundledConfig, configPath)
  const env = { ...process.env,
    AUTOCLIP_HOME: data,
    HF_HOME: path.join(root, 'hf-home'),
    HF_HUB_CACHE: path.join(root, 'hf-home', 'hub'),
    HUGGINGFACE_HUB_CACHE: path.join(root, 'hf-home', 'hub'),
    OLLAMA_MODELS: path.join(root, 'ollama-models'),
    OLLAMA_NO_CLOUD: '1',
    OLLAMA_HOST: '127.0.0.1:11435',
    HOME: path.join(root, 'ollama-home'),
    USERPROFILE: path.join(root, 'ollama-home'),
    TEMP: temp, TMP: temp,
    PATH: [ollamaRoot, path.join(tools, 'ffmpeg-full', 'bin'),
      path.join(tools, 'python312'), path.join(tools, 'python312', 'Scripts'), process.env.PATH].join(path.delimiter)
  }
  fs.mkdirSync(env.HOME, { recursive: true })
  const ollamaExe = path.join(ollamaRoot, 'ollama.exe')
  if (fs.existsSync(ollamaExe) && !(await probe('http://127.0.0.1:11435/api/tags'))) {
    if (!(await runOllamaCheck(ollamaExe, env))) {
      const ollama = spawn(ollamaExe, ['serve'], { cwd: root, env, detached: true, stdio: 'ignore', windowsHide: true })
      ollama.unref()
    }
  }
  const service = 'http://127.0.0.1:8000/api/health'
  if (!(await probe(service))) {
    const python = path.join(tools, 'python312', 'python.exe')
    const logPath = path.join(data, 'desktop.log')
    const log = fs.openSync(logPath, 'a')
    backend = spawn(python, ['-m', 'autoclip.cli', 'serve', '--host', '127.0.0.1', '--no-open'],
      { cwd: appRoot, env, stdio: ['ignore', log, log], windowsHide: true })
    backend.on('exit', (code) => {
      if (!shuttingDown && windowRef && !windowRef.isDestroyed()) {
        dialog.showErrorBox('AutoClip stopped', `The local service exited (${code ?? 'unknown'}). See work\\autoclip-data\\desktop.log.`)
      }
    })
    await waitFor(service)
  }
  createWindow()
}

function createWindow() {
  windowRef = new BrowserWindow({
    width: 1440, height: 960, minWidth: 900, minHeight: 650,
    title: 'AutoClip', backgroundColor: '#f4f0e9',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
  })
  windowRef.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith('http://127.0.0.1:8000') && !url.startsWith('http://localhost:8000')) shell.openExternal(url)
    return { action: 'deny' }
  })
  windowRef.loadURL('http://127.0.0.1:8000')
  windowRef.on('closed', () => { windowRef = null })
}

app.whenReady().then(() => launch().catch(err => {
  dialog.showErrorBox('Could not start AutoClip', err.message || String(err))
  app.quit()
}))
app.on('before-quit', () => { shuttingDown = true; if (backend && backend.exitCode === null) backend.kill() })
app.on('window-all-closed', () => app.quit())

