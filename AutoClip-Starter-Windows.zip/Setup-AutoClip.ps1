$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$pythonVersion = '3.12.10'
$electronVersion = '45.3.2'
$installRoot = Join-Path $env:LOCALAPPDATA 'AutoClip'
$workRoot = Join-Path $installRoot 'work'
$appRoot = Join-Path $workRoot 'autoclip-main'
$downloads = Join-Path $installRoot 'downloads'
$pythonRoot = Join-Path $workRoot 'tools\python312'
$ollamaRoot = Join-Path $workRoot 'tools\ollama'
$ffmpegRoot = Join-Path $workRoot 'tools\ffmpeg-full\bin'
$electronRoot = Join-Path $installRoot 'desktop\electron'
$modelsRoot = Join-Path $workRoot 'ollama-models'
$hfRoot = Join-Path $workRoot 'hf-home'
$dataRoot = Join-Path $workRoot 'autoclip-data'

function Download-File([string]$Url, [string]$Path) {
    if (Test-Path -LiteralPath $Path) { return }
    Write-Host "Downloading $([IO.Path]::GetFileName($Path)) ..." -ForegroundColor Cyan
    $partial = $Path + '.partial'
    if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
    Invoke-WebRequest -Uri $Url -OutFile $partial -UseBasicParsing
    if (!(Test-Path -LiteralPath $partial) -or (Get-Item -LiteralPath $partial).Length -lt 10000) {
        throw "The download from $Url did not complete correctly. Run Setup AutoClip.cmd again."
    }
    Move-Item -LiteralPath $partial -Destination $Path -Force
}
function Copy-Tree([string]$Source, [string]$Destination) {
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    & robocopy $Source $Destination /E /XD .git node_modules __pycache__ tests /XF *.pyc /NFL /NDL /NJH /NJS /NC /NS | Out-Null
    if ($LASTEXITCODE -gt 7) { throw "Could not copy app files (robocopy code $LASTEXITCODE)." }
}
function Make-Shortcut([string]$Name, [string]$Target) {
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $shell = New-Object -ComObject WScript.Shell
        $link = $shell.CreateShortcut((Join-Path $desktop ($Name + '.lnk')))
        $link.TargetPath = $Target
        $link.WorkingDirectory = $installRoot
        $link.Save()
    } catch { Write-Host "Open $Target from File Explorer if a desktop shortcut cannot be created." -ForegroundColor Yellow }
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or ![Environment]::Is64BitOperatingSystem) { throw 'This starter package is for 64-bit Windows.' }
New-Item -ItemType Directory -Force -Path $downloads,$workRoot,$dataRoot,$modelsRoot,$hfRoot,(Join-Path $workRoot 'ollama-home'),(Join-Path $workRoot 'temp') | Out-Null
Write-Host 'Installing AutoClip into your Windows user folder. No administrator account is needed.' -ForegroundColor Green
Copy-Tree (Join-Path $PSScriptRoot 'autoclip-main') $appRoot
New-Item -ItemType Directory -Force -Path (Join-Path $installRoot 'desktop') | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'desktop\main.js') (Join-Path $installRoot 'desktop\main.js') -Force
Copy-Item (Join-Path $PSScriptRoot 'desktop\package.json') (Join-Path $installRoot 'desktop\package.json') -Force
if (!(Test-Path -LiteralPath (Join-Path $dataRoot 'config.json'))) { Copy-Item (Join-Path $PSScriptRoot 'config.template.json') (Join-Path $dataRoot 'config.json') }

# Download a private Python runtime.
$pythonExe = Join-Path $pythonRoot 'python.exe'
if (!(Test-Path -LiteralPath $pythonExe)) {
    $pythonZip = Join-Path $downloads "python-$pythonVersion-embed-amd64.zip"
    Download-File "https://www.python.org/ftp/python/$pythonVersion/python-$pythonVersion-embed-amd64.zip" $pythonZip
    New-Item -ItemType Directory -Force -Path $pythonRoot | Out-Null
    Expand-Archive -LiteralPath $pythonZip -DestinationPath $pythonRoot -Force
    @('python312.zip','.','Lib\site-packages','import site') | Set-Content -LiteralPath (Join-Path $pythonRoot 'python312._pth')
    New-Item -ItemType Directory -Force -Path (Join-Path $pythonRoot 'Lib\site-packages') | Out-Null
    $pipScript = Join-Path $downloads 'get-pip.py'
    Download-File 'https://bootstrap.pypa.io/get-pip.py' $pipScript
    & $pythonExe $pipScript --disable-pip-version-check --no-warn-script-location
    if ($LASTEXITCODE -ne 0) { throw 'Could not prepare Python packages. Run Setup AutoClip.cmd again.' }
}

# Install the app's Python packages. NVIDIA support is included on NVIDIA PCs.
$nvidia = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'NVIDIA' }
$installSpec = $appRoot
if ($nvidia) { $installSpec += '[gpu]' }
Write-Host 'Installing video and transcription components. This can take a while.' -ForegroundColor Cyan
& $pythonExe -m pip install --disable-pip-version-check --no-cache-dir -e $installSpec
if ($LASTEXITCODE -ne 0) { throw 'AutoClip components did not finish installing. Check internet and rerun Setup AutoClip.cmd.' }

# Download FFmpeg full build, including caption-rendering support.
if (!(Test-Path -LiteralPath (Join-Path $ffmpegRoot 'ffmpeg.exe'))) {
    $ffmpegZip = Join-Path $downloads 'ffmpeg-release-full.zip'
    Download-File 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-full.zip' $ffmpegZip
    $extract = Join-Path $downloads 'ffmpeg-extract'
    if (Test-Path $extract) { Remove-Item -LiteralPath $extract -Recurse -Force }
    Expand-Archive -LiteralPath $ffmpegZip -DestinationPath $extract -Force
    $ffmpegExe = Get-ChildItem -LiteralPath $extract -Recurse -Filter ffmpeg.exe | Select-Object -First 1
    if (!$ffmpegExe) { throw 'The FFmpeg download did not contain ffmpeg.exe.' }
    New-Item -ItemType Directory -Force -Path $ffmpegRoot | Out-Null
    Copy-Item -Path (Join-Path $ffmpegExe.Directory.FullName '*') -Destination $ffmpegRoot -Recurse -Force
    Remove-Item -LiteralPath $ffmpegZip,$extract -Recurse -Force -ErrorAction SilentlyContinue
}

# Keep Ollama and its model in this app's own local data folder.
$ollamaExe = Join-Path $ollamaRoot 'ollama.exe'
if (!(Test-Path -LiteralPath $ollamaExe)) {
    $ollamaZip = Join-Path $downloads 'ollama-windows-amd64.zip'
    Download-File 'https://github.com/ollama/ollama/releases/latest/download/ollama-windows-amd64.zip' $ollamaZip
    $extract = Join-Path $downloads 'ollama-extract'
    if (Test-Path $extract) { Remove-Item -LiteralPath $extract -Recurse -Force }
    Expand-Archive -LiteralPath $ollamaZip -DestinationPath $extract -Force
    $ollamaFound = Get-ChildItem -LiteralPath $extract -Recurse -Filter ollama.exe | Select-Object -First 1
    if (!$ollamaFound) { throw 'The Ollama download did not contain ollama.exe.' }
    New-Item -ItemType Directory -Force -Path $ollamaRoot | Out-Null
    Copy-Item -Path (Join-Path $ollamaFound.Directory.FullName '*') -Destination $ollamaRoot -Recurse -Force
    Remove-Item -LiteralPath $ollamaZip,$extract -Recurse -Force -ErrorAction SilentlyContinue
}

# Download the Electron window runtime separately from this small starter.
$electronExe = Join-Path $electronRoot 'electron.exe'
if (!(Test-Path -LiteralPath $electronExe)) {
    $electronZip = Join-Path $downloads "electron-v$electronVersion-win32-x64.zip"
    Download-File "https://github.com/electron/electron/releases/download/v$electronVersion/electron-v$electronVersion-win32-x64.zip" $electronZip
    New-Item -ItemType Directory -Force -Path $electronRoot | Out-Null
    Expand-Archive -LiteralPath $electronZip -DestinationPath $electronRoot -Force
    Remove-Item -LiteralPath $electronZip -Force -ErrorAction SilentlyContinue
}

# Use an isolated, loopback-only Ollama port and explicitly disable Ollama cloud.
$env:OLLAMA_MODELS = $modelsRoot
$env:OLLAMA_HOST = '127.0.0.1:11435'
$env:OLLAMA_NO_CLOUD = '1'
$env:HOME = Join-Path $workRoot 'ollama-home'
$env:USERPROFILE = $env:HOME
$env:HF_HOME = $hfRoot
$env:HF_HUB_CACHE = Join-Path $hfRoot 'hub'
$env:HUGGINGFACE_HUB_CACHE = $env:HF_HUB_CACHE
$env:AUTOCLIP_HOME = $dataRoot
$env:TEMP = Join-Path $workRoot 'temp'
$env:TMP = $env:TEMP
$env:PATH = "$ollamaRoot;$ffmpegRoot;$pythonRoot;$($pythonRoot)\Scripts;$env:PATH"
New-Item -ItemType Directory -Force -Path $env:HOME,$env:HF_HUB_CACHE,$env:TEMP | Out-Null
$ollamaApi = 'http://127.0.0.1:11435/api/tags'
try { $null = Invoke-RestMethod -Uri $ollamaApi -TimeoutSec 2 }
catch {
    Start-Process -FilePath $ollamaExe -ArgumentList 'serve' -WorkingDirectory $workRoot -WindowStyle Hidden
    $ready = $false
    for ($i=0; $i -lt 90; $i++) { Start-Sleep -Seconds 1; try { $null = Invoke-RestMethod -Uri $ollamaApi -TimeoutSec 2; $ready=$true; break } catch {} }
    if (!$ready) { throw 'The local AI service did not start. Restart Windows and rerun Setup AutoClip.cmd.' }
}
Write-Host 'Downloading the local highlight model (about 2 GB).' -ForegroundColor Cyan
& $ollamaExe pull 'llama3.2:3b'
if ($LASTEXITCODE -ne 0) { throw 'Could not download the local AI model. Check internet and rerun Setup AutoClip.cmd.' }
Write-Host 'Preparing the local Whisper transcription model (about 0.5 GB).' -ForegroundColor Cyan
& $pythonExe -c "from faster_whisper import WhisperModel; WhisperModel('small', device='cpu', compute_type='int8'); print('Whisper model ready')"
if ($LASTEXITCODE -ne 0) { throw 'Could not prepare Whisper. Check internet and rerun Setup AutoClip.cmd.' }

# Install launch files and add shortcuts.
if (Test-Path -LiteralPath $downloads) { Remove-Item -LiteralPath $downloads -Recurse -Force }
foreach ($name in @('AutoClip-Environment.ps1','Start-AutoClip-Browser.ps1','Start-AutoClip-Desktop.ps1','Start AutoClip Browser.cmd','Start AutoClip Desktop.cmd')) {
    Copy-Item (Join-Path $PSScriptRoot $name) (Join-Path $installRoot $name) -Force
}
Make-Shortcut 'AutoClip Browser' (Join-Path $installRoot 'Start AutoClip Browser.cmd')
Make-Shortcut 'AutoClip Desktop' (Join-Path $installRoot 'Start AutoClip Desktop.cmd')
Write-Host ''
Write-Host 'AutoClip is ready. Shortcuts were added to your desktop.' -ForegroundColor Green
Write-Host 'The setup downloads were removed; models and runtime stay local on this PC.' -ForegroundColor Green
